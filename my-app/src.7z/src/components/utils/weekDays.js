const weekDayArr = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

export default weekDayArr;